import React, { Component } from 'react';
import Taskbar from './Taskbar'
import './App.css';
import TodoList from './TodoList'
class App extends Component {
  render() {
    return (
      <div>
        <Taskbar />
        <TodoList />
      </div>
    );
  }
}

export default App;
