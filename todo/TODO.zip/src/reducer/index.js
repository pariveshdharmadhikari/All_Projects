import {combineReducers} from 'redux';

//Reducers to perform action for selected song
const TodoItem= (task=[],action) => {
   
    if(action.type === 'TASK'){
        return [...task, action.payload];
        
    }
    
    return task;
};


//it will make combine set of reducers
export default combineReducers({
    task:TodoItem
});