import React from 'react'
import './Taskbar.css';
import {connect} from 'react-redux';
import {Todo} from './action'


class Taskbar extends React.Component{
    state={ term :'',flag:false};
    
    setTerm = (event) =>{
        this.setState({term:event.target.value,flag:true});
    }

    submitTerm=(event)=>{
        event.preventDefault();
        if(this.state.term!==''){
        this.props.Todo(this.state.term);
        this.setState({term:''});
    }
}
    
    render(){
        
        return(
            
            <div className='taskbar'>
                <form onSubmit={this.submitTerm}>
                    <h4>Add Task</h4>
                    <input value={this.state.term} onChange={this.setTerm} ></input>
                   
                </form>
                
            </div>
            
        );
    };
}

export default connect(null,{Todo})(Taskbar);