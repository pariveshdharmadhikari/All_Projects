import React from 'react'
import './TodoList.css';
import { connect } from 'react-redux';
// import TodoItem from './TodoItem'
// import {Icon} from 'semantic-ui-react';
import { Todo } from './action';
import Popup from "reactjs-popup";


class TodoList extends React.Component {
    constructor(props) {
        super(props);
        this.state = { currentid:'',allTasks: [],term :'', render: false, openPopup: false };
    }

    componentWillReceiveProps() {
        this.setState({ render: true })

    }

    removetask = (id) => {
        const dataArray = this.state.allTasks;
        dataArray.splice(id, 1);
        this.setState({ allTasks: dataArray });
    }

    edittask = (id) => {
        this.setState({ openPopup: true ,currentid:id });        
    }

    updateTask=(id)=>{
        let data=this.state.term
        const dataArray = this.state.allTasks;
        if(data!==''){
        dataArray.splice(this.state.currentid,1,data);
        this.setState({allTasks:dataArray});}
        this.setState({ openPopup: false });

    }


    taskList = () => {

        if (this.state.render) {
            this.setState(
                { allTasks: this.props.tasks, render: false });
        }
        {
            const data = this.state.allTasks.map((task, id) => {
                return (
                    <div className="taskitem" key={id}>
                       
                        <div className="maintask">
                            {task}
                            <i onClick={() => this.removetask(id)} className="eraser icon ierase large"></i>
                            <i onClick={() => this.edittask(id)} className="edit icon ierase large"></i>
                            
                            <Popup
                                open={this.state.openPopup}
                                modal={true}
                            >
                            
                                <div>
                                <h3>Enter Updated Task</h3>
                                <input onChange={(event)=>{this.setTerm(event)}}></input>
                                <button type='submit' onClick={() => {this.updateTask(id)}}>Save</button>
                                </div>
                            </Popup>
                       
                        </div>
                    </div>
                );


            });
            return <div>{data}</div>
        }
    }

    setTerm = (event) =>{
        this.setState({term:event.target.value,});
    }

    render() {
        return (
            <div>
                {this.taskList()}
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return { tasks: state.task }
}
export default connect(mapStateToProps, { Todo })(TodoList);