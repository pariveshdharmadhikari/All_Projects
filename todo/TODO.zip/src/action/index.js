export const Todo= task => {
    //Return an action as object
    return{
        type:'TASK',
        payload: task

    };

}
